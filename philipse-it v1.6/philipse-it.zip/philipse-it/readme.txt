=== Philipse IT ===
Contributors: Feike Falkena
Tags: vanish, hide, dashboard, SiteKit
Requires at least: 4.2
Tested up to: 5.4.2
Requires PHP: 5.6.40
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Hide dashboard items and Google Site Kit from users.